<template>
  <div class="home">
    

    <!-- 轮播图 -->
    <el-row type="flex" justify="center">
      <el-col :span="24">
        <agwcarousel></agwcarousel>
      </el-col>
    </el-row>
    
    <!-- 限时秒杀 -->
    <el-row class="hotset" type="flex">
      <el-col style="width:250px;">
        <div class="hottip">
          <img src="../assets/hot.png" alt="">
          <span>限时秒杀</span>
        </div>
      </el-col>
      <el-col>
        <div class="hotgoods">
          <el-card :body-style="{ padding: '0px' }" shadow="never" v-for="g in goods" :key="g.id">
            <img :src="$webroot+'img/'+g.goodimg" class="image">
            <div style="padding: 14px;">
              <div style="display:flex;justify-content:space-between">
                <span>{{g.goodname}}</span>
                <span style="color:red;font-size:20px"><img src="../assets/fire.png" alt="" width="20px" height="20px">{{g.goodprice}}</span>
              </div>
              <div class="bottom clearfix">
                <el-button type="text" class="button" @click="gooddetail(g.id)">查看</el-button>
              </div>
            </div>
          </el-card>
        </div>
      </el-col>
      
    </el-row>

    <!-- 推荐 -->
    <el-row class="contentset">
      <el-col :span="24">
        <el-row>
          <el-col :span="24" class="tipset">
            <h2>猜你喜欢</h2>
          </el-col>
        </el-row>

        <el-row type="flex" justify="space-around" class="otherset">
          <el-col class="otherelcol"> 
            <div class="otheritem">
              <img src="../assets/manhua1.jpg" alt="" @click="otherjump()">
            </div>
          </el-col>
          <el-col class="otherelcol">
            <div class="otheritem">
              <img src="../assets/manhua2.jpg" alt="" @click="otherjump()">
            </div>
          </el-col>
          <el-col class="otherelcol">
            <div class="otheritem">
              <img src="../assets/manhua3.jpg" alt="" @click="otherjump()">
            </div>
          </el-col>
          <el-col class="otherelcol">
            <div class="otheritem">
              <img src="../assets/manhua4.jpg" alt="" @click="otherjump()">
            </div>
          </el-col>
        </el-row>
        
      </el-col>
    </el-row>
  </div>
</template>

<script>
import agwcarousel from '../components/agwcarousel';

export default {
  name: 'Home',
  components: {
    agwcarousel,
  },
  data(){
    return{
      goods:[
        {id:1,goodname:"11",goodprice:100,goodimg:""},
        {id:2,goodname:"11",goodprice:100,goodimg:""},
        {id:3,goodname:"11",goodprice:100,goodimg:""},
        {id:4,goodname:"11",goodprice:100,goodimg:""},
        {id:5,goodname:"11",goodprice:100,goodimg:""}
      ],
      morecss:"moregood",
      moreisactive:false,
      moreactive:"moreactive"

    }
  },
  mounted:function(){
    this.homeset();
  },
  methods:{
    gooddetail(val){
      sessionStorage.setItem('goodid',val);
      this.$router.push('/gdetail');
    },

    homeset(){
      // 限时秒杀
      axios.post(
        this.$webroot+"goods/find"
      )
      .then((response)=>{
        this.goods = response.data
      })
      .catch((error)=>{
        console.log(error);
        return false;
      })
    },

    otherjump(){
      // this.$router.push("/other")
    }
  }
  
}
</script>

<style scoped>
  .home{
    width: 1200px;
    margin: 0 auto;
  }
  
  .bottom {
    margin-top: 10px;
    line-height: 12px;
  }

  .button {
    padding: 0;
    float: right;
  }

  .image {
    width: 180px;
    height: 200px;
    display: block;
    margin: 10px;
  }

  .clearfix:before,
  .clearfix:after {
      display: table;
      content: "";
  }
  
  .clearfix:after {
      clear: both
  }

  .el-card{
    width: 200px;
  }

  .tipset{
    text-align: center;
    color: black;
    border-bottom: 1px solid #6d6d6d;
  }

  .tipset h2{
    margin: 10px 0;
    padding: 0;
  }

  .contentset{
    padding: 0;
    margin: 10px 0;
  }

  .hotset{
    padding: 0;
    border-radius: 10px;
    margin: 10px 0;
    height: 300px;
  }

  .hottip{
    height: 100%;
    background-color: red;
    color: white;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    text-align: center;
    display: flex;
    flex-direction: column;
  }

  .hottip img{
    width: 200px;
    height: 200px;
    margin-top: 20px;
  }

  .hottip span{
    font-size: 25px;
  }

  .hotgoods{
    display: flex;
    width: 1000px;
  }

  .moregood{
    box-sizing: border-box;
    width: 50px;
    height: 100%;
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    background-color: rgba(235, 81, 34, 0.4);
    position: relative;
    text-align: center;
  }

  .moregood span{
    position: absolute;
    top: 30%;
    left: 0;
    font-size: 29px;
    
    cursor: pointer;
  }

  .morelink{
    text-decoration: none;
    color: white;
  }

  .moreactive{
    background-color: rgba(235, 81, 34, 1);
  }

  .otherset{
    flex-wrap: wrap;
  }

  .otherelcol{
    width:500px;
    margin-top:30px;
  }

  .otheritem{
    width: 450px;
    height: 250px;
    margin: auto;
    cursor: pointer;
    /* background-color: orangered; */
  }

  .otheritem img{
    border-radius: 15px;
    width: 450px;
    height: 250px;
  }

</style>
