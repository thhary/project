<template>
    <div id="gdetail">
        <el-row type="flex">
            <!-- 图片区 -->
            <el-col :span="6" class="goodleft">
                <!-- 大图 -->
                <el-row>
                    <el-col :span="24">
                        <img :src="bigimg()" alt="" class="firstimg">
                    </el-col>
                </el-row>
                <!-- 小图 -->
                <el-row>
                    <el-col :span="24">
                        <div class="others" ref="others" style="width:330px">
                            <ul style="left:0" class="otherslist" ref="otherlist">
                                <li v-for="(i,index) in otherimg" :key="index">
                                    <img :src="otherimgs(i)" alt="" class="otherimg" @mouseenter="imgindex = index">
                                </li>
                            </ul>
                            <div class="imgbtn leftbtn" :class="isactive?activeclass:''" @mouseenter="isactive = true" @mouseleave="isactive = false" @click="goleft()">&lt;</div>
                            <div class="imgbtn rightbtn" :class="isactive?activeclass:''" @mouseenter="isactive = true" @mouseleave="isactive = false" @click="goright()">&gt;</div>
                        </div>
                    </el-col>
                </el-row>
            </el-col>
            <!-- 商品内容区 -->
            <el-col :span="18" class="goodright">
                <h1>{{good.goodname}}</h1>
                <table cellspacing="0">
                    <tr class="gdiv1">
                        <td>售价：</td>
                        <td style="color:red">
                            ￥<span style="font-size:30px">{{good.goodprice}}</span>
                        </td>
                    </tr>
                    <tr>
                        <td>服务支持：</td>
                        <td>7天无理由退款</td>
                    </tr>
                    <tr>
                        <td>选择款式：</td>
                        <td class="gtypes">
                            <div class="goodtype" :class="ogood.goodtype == good.goodtype?'goodactive':''" v-for="ogood in othergood" :key="ogood.id" @click="goodjump(ogood.id)">
                                <img :src="typeimg(ogood.goodimg)" alt="" width="30px" height="30px">
                                <span style="line-height:30px">{{ogood.goodname}}</span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="goodnum">
                                <button @click="reducenum" class="setnum">-</button>
                                <input type="text" v-model="goodnum">
                                <button @click="addnum" class="setnum">+</button>
                                <button class="addbc" @click="addbc">添加购物车</button>
                            </div>
                        </td>
                    </tr>
                </table>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="24">
                <el-tabs type="border-card">
                    <el-tab-pane label="商品介绍">
                        <img :src="goodimgs(gimg)" alt="" width="100%" v-for="(gimg,index) in otherimg" :key="index">
                    </el-tab-pane>
                    <el-tab-pane label="售后保障">
                        售后保障
                    </el-tab-pane>
                </el-tabs>
            </el-col>
        </el-row>
    </div>
</template>

<script>
export default {
    name:"gdetail",
    inject:['reload'],
    data(){
        return{
            goodid:JSON.parse(sessionStorage.getItem("goodid")),
            otherimg:['manhua1.jpg','manhua2.jpg','manhua3.jpg','manhua4.jpg','manhua5.jpg'],
            imgindex:0,
            activeclass:'activeclass',
            isactive:false,
            good:null,
            addvalue:'',
            othergood:[],
            goodnum:0

        }
    },

    methods:{
        gooddetailload(){
            console.log(this.goodid);
            axios.post(
                this.$webroot+"goods/findbyid",
                "goodid=" + this.goodid
            ).then((response)=>{
                if(response.data.err){
                    console.log(response.data.err);
                    return;
                }
                this.good = response.data.good;
                this.othergood = response.data.othergood;
            }).catch((error)=>{console.log(error)})
        },

        otherimgs(val){
            return require('../assets/'+val);
            // return require(this.$webroot+'img/'+val);
        },

        bigimg(){
            return require('../assets/'+this.otherimg[this.imgindex]);
            // return require(this.$webroot+'img/'+this.otherimg[this.imgindex]);
        },

        goleft(){
            var imgcount = Number(this.otherimg.length);
            var allimglength = imgcount * 80;
            var otherslenght = Number(this.$refs.others.style.width.split('px')[0]);
            var leftvalue = Number(this.$refs.otherlist.style.left.split('px')[0]);
            if(allimglength - otherslenght + 10 < 0){
                return;
            }
            if(leftvalue + 80 > 0){
                return;
            }
            this.$refs.otherlist.style.left = Number(leftvalue) + 80 + 'px';
        },

        goright(){
            var imgcount = Number(this.otherimg.length);
            var allimglength = imgcount * 80;
            var otherslenght = Number(this.$refs.others.style.width.split('px')[0]);
            var leftvalue = Number(this.$refs.otherlist.style.left.split('px')[0]);
            if(allimglength - otherslenght + 10 < 0){
                return;
            }
            if(leftvalue - 80 < -(allimglength - otherslenght+10)){
                return;
            }
            this.$refs.otherlist.style.left = leftvalue - 80 + 'px';
        },

        handleChange(value) {
            console.log(value);
        },

        addnum(){
            this.goodnum =Number(this.goodnum) + 1;
        },

        reducenum(){
            if (this.goodnum != 0) {
                this.goodnum =Number(this.goodnum) - 1;
            }
        },

        addbc(){
            axios.post(
                this.$webroot + "buycars/insert",
                "goodid=" + this.goodid + "&goodnum=" + this.goodnum+"&userid="+ sessionStorage.getItem("user").userid
            ).then((response)=>{
                this.$router.push("/buycar");
            }).catch((error)=>{console.log(error)})
        },
        typeimg(val) {
            return require("../assets/hot.png");
            // return require(this.$webroot+'img/'+val);
        },
        goodjump(val){
            sessionStorage.setItem("goodid",val);
            this.reload();
        },
        goodimgs(val){
            return require('../assets/'+val);
            // return require(this.$webroot+'img/'+val);
        }
    },

    mounted:function () {
        this.gooddetailload();
    }
}
</script>

<style scoped>
    #gdetail{
        box-sizing: border-box;
        width: 1200px;
        margin: 0 auto;
        padding: 10px;
    }

    .goodleft{
        display: inline-block;
        min-width:350px;
        height: 500px;
    }

    .firstimg{
        width: 330px;
        height: 350px;
        margin: 10px;
    }

    .others{
        height: 100px;
        margin: 0 10px;
        padding: 0;
        position: relative;
        overflow: hidden;
        box-sizing: border-box;
    }

    .otherslist{
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        position: absolute;
        top: 10px;
    }

    .otherslist li{
        display: inline-block;
        margin: 0 5px;
    }

    .otherimg{
        width: 70px;
        height: 80px;
        cursor: pointer;
    }

    .imgbtn{
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        opacity: 0.5;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        z-index: 10;
        background-color: gray;
        color: white;
        text-align: center;
        font-size: 20px;
        line-height: 30px;
        cursor: pointer;
    }

    .leftbtn{
        left: -10px;
    }

    .rightbtn{
        right: -10px;
    }

    .activeclass{
        opacity: 0.9;
    }

    .goodright{
        /* background-color:orange; */
        padding: 10px;
        padding-left: 30px;
        display: flex;
        flex-direction: column;
    }

    /* .goodright h1{
        margin: 0;
        padding: 0;
    } */

    .goodright p{
        margin: 10px 0;
        padding: 0;
    }

    .gdiv1{
        margin: 0;
        padding: 0;
        background-color: rgb(226, 224, 224);
    }

    .goodright table tr td{
        padding: 10px 5px;
    }

    .goodright table tr>td:first-child{
        width: 100px;
    }

    .gtype{
        display:flex;
        flex-wrap: wrap;

    }

    .goodtype{
        display: inline-block;
        margin: 10px;
        width: 100px;
        height: 30px;
        border: 1px solid grey;
        border-radius: 5px;
        display: flex;
        cursor: pointer;

    }

    .goodnum button{
        outline: none;
    }

    .goodnum input{
        width: 50px;
        height: 30px;
    }

    .setnum{
        height: 36px;
    }

    .addbc{
        margin-left: 30px;
        width: 150px;
        height: 50px;
        background-color: #FFD04B;
        color: white;
        border: 1px solid #FFD04B;
        padding: 0;
        font-size: 20px;
    }

    .goodactive{
        border: 1px solid #FFD04B;
    }


</style>