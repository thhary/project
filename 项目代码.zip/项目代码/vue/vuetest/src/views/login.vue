<template>
    <div>
        <router-link to="/"><logo></logo></router-link>
        <el-row type="flex" justify="center" class="frow">
            <el-col style="width:400px">
                <div class="loginimg">
                    <h1>爱购物，购你所想</h1>
                    <p>一个专做购物的老品牌</p>
                    <p>价格优惠，保证正品</p>
                    <p>你想要的，这里都有</p>
                </div>
            </el-col>
            <el-col :span="12" class="formset">
                <el-form :model="user" :rules="rules" ref="loginform" label-width="70px" class="elform">
                    <el-form-item label="用户名" prop="name">
                        <el-input v-model="user.name"></el-input>
                    </el-form-item>
                    <el-form-item label="密码" prop="pwd">
                        <el-input v-model="user.pwd"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-checkbox v-model="isremember">记住我</el-checkbox>
                        <el-link type="primary" :underline="false" style="float:right" @click="regnow()">立即注册</el-link>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="submitForm()">登录</el-button>
                        <el-button @click="resetForm()">重置</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import qs from 'qs';
import logo from '../components/logo';
export default {
    components:{
        logo,
    },
    data() {
        return {
            // 用户
            user: {
                name: '',
                pwd: ''
            },
            // 输入规则
            rules: {
                name: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                ],
                pwd:[
                    { required: true, message: '请输入密码', trigger: 'blur' },
                ]
            },
            // 记住我
            isremember:false
        };
    },
    methods: {
        // 提交表单
        submitForm() {
            this.$refs.loginform.validate((valid) => {
            if (valid) {
                this.login();
            } else {
                console.log('error submit!!');
                return false;
            }
            });
        },
        // 重置表单
        resetForm() {
            this.$refs.loginform.resetFields();
        },
        // 登录
        login() {
            axios.post(
                this.$webroot+"users/login",
                qs.stringify(this.user)
            )
            .then((response)=>{
                if (response.data.err) {
                    console.log(response.data.err);
                    return
                }
                sessionStorage.setItem("user",response.data);
                // sessionStorage.setItem("token",response.headers.token);
                this.$router.push("/");
            })
            .catch((error)=>{
                console.log(error);
            })
        },
        regnow(){
            this.$router.push("/reg");
        }
    }
  
}
</script>

<style scoped>
    .header{
        padding: 5px 50px;
    }
    .frow{
        /* margin-top: 300px; */
        background-color: orange;
        padding: 150px 0;
        background: url("../assets/bglogin.jpg") no-repeat;
        background-size:100% 100%;
    }

    .loginimg{
        width: 350px;
        height: 300px;
        font-size:22px;
        /* background-color: red; */
    }
    .loginimg h1{
        margin-bottom: 60px;
    }

    .formset{
        max-width:400px;
        background-color:white;
        border-radius: 15px;
        box-shadow: 10px 10px 5px rgb(168, 109, 0);
    }

    .elform{
        padding: 0 20px;
        padding-top: 30px;
    }
</style>