<template>
    <div>
        <router-link to="/"><logo/></router-link>
        <el-row type="flex" justify="center" class="frow">
            <el-col :span="12" class="formset">
                <el-form :model="user" :rules="rules" ref="loginform" label-width="70px" class="elform">
                    <el-form-item label="昵称" prop="nickname">
                        <el-input v-model="user.nickname"></el-input>
                    </el-form-item>
                    <el-form-item label="姓名" prop="username">
                        <el-input v-model="user.username"></el-input>
                    </el-form-item>
                    <el-form-item label="密码" prop="pwd">
                        <el-input v-model="user.pwd"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="submitForm()">注册</el-button>
                        <el-button @click="resetForm()">重置</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import qs from 'qs';
import logo from '../components/logo'

export default {
    components:{
        logo
    },
    data() {
        return {
            // 用户
            user: {
                nickname:'',
                username: '',
                pwd: ''
            },
            // 输入规则
            rules: {
                nickname: [
                    { required: true, message: '请输入昵称', trigger: 'blur' },
                ],
                username: [
                    { required: true, message: '请输入姓名', trigger: 'blur' },
                ],
                pwd:[
                    { required: true, message: '请输入密码', trigger: 'blur' },
                ]
            },
        };
    },
    methods:{
        // 提交表单
        submitForm() {
            this.$refs.loginform.validate((valid) => {
            if (valid) {
                this.reg();
            } else {
                console.log('error submit!!');
                return false;
            }
            });
        },
        // 重置表单
        resetForm() {
            this.$refs.loginform.resetFields();
        },
        // 注册
        reg(){
            axios.post(
                this.$webroot+'',
                qs.stringify(this.user)
            ).then((response)=>{
                if (response.data.err) {
                    console.log(response.data.err);
                    return;
                }
                this.$router.push('/login');
            }).catch((error)=>{
                console.log(error);
            })
        }
    }

}
</script>

<style scoped>
    .frow{
        /* margin-top: 40px; */
        /* background-color: orange; */
        background: url("../assets/bgreg.png") no-repeat;
        background-size:100% 100%;
        padding: 180px 0;
    }

    .formset{
        max-width:400px;
        background-color:white;
        border-radius: 15px;
        box-shadow: 10px 10px 5px rgb(168, 109, 0);
    }

    .elform{
        padding: 0 20px;
        padding-top: 30px;
    }
</style>