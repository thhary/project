<template>
    <div id="sere">
        <ul class="resultvalue" v-if="havegood">
            <li class="onevalue" v-for=" sr in totalpage" :key="sr.id">
                <img :src="imgurl" alt="" width="200px" height="200px" @click="gooddetail(sr.id)">
                <p class="goodprice">￥{{sr.price}}</p>
                <p class="goodname" 
                    :class="sr.id == isthisname?goodnameactive:''" 
                    @mouseenter="isthisname = sr.id"
                    @mouseleave="isthisname = ''"
                    @click="gooddetail(sr.id)">{{sr.name}}</p>
                <p class="goodcontent">{{sr.content}}</p>
                <p class="evaluation"><span @click="peopleeval()">{{sr.people}}</span>评价</p>
            </li>
        </ul>
        <div v-else class="nogood">
            <img src="../assets/sbox.png" alt="">
            <h3>抱歉，未找到商品</h3>
        </div>
        <div>
            <el-pagination
            background
            :hide-on-single-page="true"
            @size-change="handlesizechange"
            @current-change="handlecurrentchange"
            :current-page="nowpage"
            :page-size="pagesize"
            layout="prev, pager, next"
            :total="searchresult.length"
            style="margin:auto"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
import qs from 'qs';
export default {
    data(){
        return{
            havegood:true,
            isthisname:'',
            goodnameactive:"goodnameactive",
            searchresult:[
                {id:1,name:"111",img:"manhua1.jpg",content:'1111',price:'1',people:'100'},
                {id:2,name:"222",img:"",content:'2222',price:'100',people:'100'},
                {id:3,name:"333",img:"",content:'3333',price:'2',people:'100'},
                {id:4,name:"444",img:"",content:'4444',price:'3',people:'100'},
                {id:5,name:"555",img:"",content:'5555',price:'4',people:'100'},
                {id:6,name:"555",img:"",content:'66666',price:'5',people:'100'},
            ],
            searchname:this.$store.state.inputcontent,
            searchtype:this.$store.state.typeid,
            imgurl:require("../assets/manhua1.jpg"),
            totalpage:[],
            totals:'',
            pagesize:25,
            nowpage:1,
        }
    },

    methods:{
        loadresult(){
            console.log(this.searchtype);
            this.setpaginations();
            if(this.searchname != null && this.searchname != ''){
                console.log(this.searchname);
                axios.post(
                    this.$webroot+"goods/findbySearchvalue",
                    "searchvalue="+this.searchname
                ).then((response)=>{
                    if(response.data.err || response.data.goods == '' || response.data.goods == null){
                        this.havegood = false;
                        return;
                    }
                    this.havegood = true;
                    this.searchresult = response.data.goods;
                    this.setpaginations();
                    this.$store.commit("removesearch");
                    return;
                }).catch((error)=>{console.log(error)})
            }else if(this.searchtype != null && this.searchtype != ''){
                console.log(this.searchtype)
                axios.post(
                    this.$webroot+"goods/findbyTypeid",
                    "typeid="+this.searchtype
                ).then((response)=>{
                    if(response.data.err || response.data.goods == '' || response.data.goods == null){
                        this.havegood = false;
                        return;
                    }
                    this.havegood = true;
                    this.searchresult = response.data.goods;
                    this.setpaginations();
                    this.$store.commit("removesearch");
                    return;
                }).catch((error)=>{console.log(error)})
            }
        },

        gooddetail(val){
            sessionStorage.setItem("goodid",val);
            this.$router.push("/gdetail");
        },

        setpaginations(){
            this.totals = this.searchresult.length;
            this.totalpage = this.searchresult.filter((item,index)=>{
                return index < this.pagesize;
            })
        },

        handlesizechange(page_size){
            this.nowpage = 1;
            this.pagesize = page_size;
            this.totalpage = this.searchresult.filter((item,index) => {
				return index < page_size
			})
        },

        handlecurrentchange(page){
            let index = this.pagesize*(page-1);
            let alldata = this.pagesize*page;
            let goodlist=[];
            for (let i = index; i < alldata; i++) {
                if(this.searchresult[i]){
                    goodlist.push(this.searchresult[i]);
                }
            }
            this.totalpage = goodlist;
        }

    },

    mounted:function () {
        this.loadresult();
    }

}
</script>

<style scoped>
    #sere{
        width: 1200px;
        margin: 0 auto;
        margin-top: 30px;
    }

    .resultvalue{
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        flex-wrap: wrap;
        box-sizing: border-box;
        /* border: 1px solid black; */
    }

    .onevalue{
        display: inline-block;
        width: 200px;
        margin: 18px;
        /* border: 1px solid black; */
    }

    .nogood{
        margin: auto;
        width: 400px;
        height: 150px;
        display: flex;
        margin-top: 70px;
    }

    .nogood h3{
        margin: 0;
        padding: 0;
        line-height: 150px;
        padding-left: 30px;
    }

    .nogood img{
        width: 150px;
        height: 150px;
    }

    .goodprice{
        color: red;
        font-size: 25px;
        margin: 0;
        padding: 0;
    }

    .goodname{
        color: gray;
        font-size: 18px;
        padding: 0;
        margin: 0;
        margin-top: 5px;
        margin-bottom: 10px;
        display: inline-block;
        cursor: pointer;
        word-wrap: break-word;
    }

    .goodnameactive{
        color: red;
    }

    .goodcontent{
        padding: 0;
        margin: 0;
        color: gray;
        margin-bottom: 10px;
        word-wrap: break-word;
    }

    .evaluation{
        margin: 0;
        padding: 0;
    }

    .evaluation span{
        color: royalblue;
        font-weight: bold;
    }

</style>