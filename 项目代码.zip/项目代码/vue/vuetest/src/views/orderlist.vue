<template>
    <div id="orderlist">
        <el-table
        :data="orderlist"
        style="width: 100%;">
            <el-table-column
                prop="orderno"
                label="订单号"
                width="150">
            </el-table-column>
            <el-table-column
                prop="createtime"
                label="时间">
            </el-table-column>
            <el-table-column
                label="商品"
                width="400">
                <template slot-scope="scope">
                    <div v-for="g in scope.row.goods" :key="g.id">
                        <div class="onegood">
                            <!-- <img :src="this.$webroot+''+scope.row.bcgoodimg" alt="" width="80px" height="80px"> -->
                            <img :src="goodimg(g.goodimg)" alt="" width="100px" height="100px">
                            <span class="gname">{{ g.goodname }}</span>
                        </div>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                width="150"
                label="支付状态">
                <template slot-scope="scope">
                    <div>
                        <span v-if="scope.row.paystate == 1">已支付</span>
                        <span v-else-if="scope.row.paystate == 2">货到付款</span>
                        <button v-else class="paybtn" @click="paymoney(scope.row.orderid)">立即支付</button>
                    </div>
                </template>
            </el-table-column>
            
            <el-table-column
                prop="address"
                width="150"
                label="地址">
            </el-table-column>
            <el-table-column
                prop="recipient"
                width="150"
                label="收货人">
            </el-table-column>
            <el-table-column
                label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
export default {
    data(){
        return{
            orderlist: [{
                orderid:1,
                orderno: '1111',
                createtime:'2020-10-10',
                goods: [{
                    goodid:1,
                    goodname:'111',
                    goodimg:'manhua1.jpg',
                },{
                    goodid:2,
                    goodname:'222',
                    goodimg:'manhua2.jpg',
                }],
                address: '上海市普陀区金沙江路 1518 弄',
                paystate:1,
                recipient:'收货人'
            }, {
                orderid:2,
                orderno: '1111',
                createtime:'2020-10-10',
                goods: [{
                    goodid:1,
                    goodname:'111',
                    goodimg:'manhua1.jpg',
                }],
                address: '上海市普陀区金沙江路 1518 弄',
                paystate:3,
                recipient:'收货人'
            }, {
                orderid:3,
                orderno: '1111',
                createtime:'2020-10-10',
                goods: [{
                    goodid:1,
                    goodname:'111',
                    goodimg:'manhua1.jpg',
                },{
                    goodid:2,
                    goodname:'222',
                    goodimg:'manhua2.jpg',
                }],
                address: '上海市普陀区金沙江路 1518 弄',
                paystate:2,
                recipient:'收货人'
            }, {
                orderid:4,
                orderno: '1111',
                createtime:'2020-10-10',
                goods: [{
                    goodid:1,
                    goodname:'111',
                    goodimg:'manhua1.jpg',
                },{
                    goodid:2,
                    goodname:'222',
                    goodimg:'manhua2.jpg',
                }],
                address: '上海市普陀区金沙江路 1518 弄',
                paystate:1,
                recipient:'收货人'
            }, ]
        }
    },
    methods:{
        orderlistload(){
            axios.post(
                this.$webroot+'orderlist/find',
            ).then((response)=>{
                if(response.data.err){
                    console.log(response.data.err);
                    return;
                }
                this.orderlist = response.data.orderlist;
            }).catch((error)=>{
                console.log(error);
                // alert('出错了');
            })
        },

        goodimg(val){
            return require('../assets/'+val);
            // return require(this.$webroot+'img/'+val);
        },

        paymoney(val){
            console.log(val);
        },

        handleDelete(index, row) {
            console.log(index, row);
            axios.post(
                this.$webroot+'orders/delete',
                "orderid="+row.orderid
            ).then((response)=>{
                if (response.data.err) {
                    console.log(err);
                    return;
                }
                this.orderlistload();
            }).catch((error)=>{
                console.log(error)
            })
        },
    },
    mounted:function () {
        this.orderlistload();
    }
}
</script>

<style scoped>
    #orderlist{
        width: 1200px;
        margin: 10px auto;
    }

    .onegood{
        /* border: 1px solid black; */
        margin: 10px 0;
        padding: 0;
        display: flex;
    }

    .gname{
        padding: 10px;
    }

    .paybtn{
        width: 100px;
        height: 50px;
        background-color: #FFD06B;
        color: white;
        outline: none;
        border: 1px solid #FFD06B;
        cursor: pointer;
        border-radius: 30px;
    }
</style>