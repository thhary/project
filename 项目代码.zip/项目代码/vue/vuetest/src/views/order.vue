<template>
    <div id="order">
        <el-row>
            <el-col :span="24" class="ordertip">
                <h2>确认订单信息</h2>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="24">
                <h4>商品信息</h4>
                <el-table
                :data="buycar"
                style="width: 100%">
                <el-table-column
                    prop="bcstorename"
                    label="店铺"
                    width="180">
                </el-table-column>
                <el-table-column
                    label="商品"
                    width="470">
                    <template slot-scope="scope">
                        <div class="onegood">
                            <!-- <img :src="this.$webroot+''+scope.row.bcgoodimg" alt="" width="80px" height="80px"> -->
                            <img :src="goodimg(scope.row.bcgoodimg)" alt="" width="100px" height="100px">
                            <span class="bcgname">{{ scope.row.bcgoodname }}</span>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="bcgoodprice"
                    label="单价"
                    width="180">
                </el-table-column>
                <el-table-column
                    prop="bcgoodnum"
                    label="数量"
                    width="180">
                </el-table-column>
                <el-table-column
                    prop="bcallprice"
                    label="小计"
                    width="180">
                </el-table-column>
                </el-table>
            </el-col>
        </el-row>
        <el-row>
            <el-col :span="24" >
                <h4>收货人信息</h4>
                <div style="display:flex;">
                    <div class="nowuser">
                        <span>收货人：</span>
                        <span class="users eleactive">{{curuser}}</span>
                    </div>
                    <div class="address">
                        <span>选择你的地址：</span>
                        <el-select v-model="orders.addressid" placeholder="请选择" @change="thischange" style="width:500px">
                            <el-option
                            v-for="item in address"
                            :key="item.id"
                            :label="item.value"
                            :value="item.id"
                            >
                            </el-option>
                        </el-select>
                    </div>
                </div>
                <el-divider></el-divider>
            </el-col>
        </el-row>
        
        <el-row>
            <el-col :span="24">
                <h4 style="margin-top:0">支付方式</h4>
                <div class="pays">
                    <!-- <span :class="thispay == 1?eleactive:''" @click="paychoose(1)">在线支付</span> -->
                    <span :class="thispay == 2?eleactive:''" @click="paychoose(2)">货到付款</span>
                </div>
                <el-divider></el-divider>
            </el-col>
        </el-row>

        <el-row type='flex' justify="end">
            <el-col :span="6">
                <table style="float:right">
                    <tr>
                        <td>总商品金额：</td>
                        <td><span class="allmoney">￥{{allmoney}}</span></td>
                    </tr>
                    <tr>
                        <td>运费：</td>
                        <td><span class="freight">￥{{freight}}</span></td>
                    </tr>
                </table>
                
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <el-row>
            <el-col :span="24" class="orderfooter">
                <div style="text-align:end;padding:10px">
                    <p style="margin:0">应付金额：<span style="font-size:25px;color:red">￥{{paymoney}}</span></p>
                    <p style="display:inline-block;color:grey;">收货人：{{curuser}}</p>
                    <p style="display:inline-block;color:grey;">地址：{{addresschoose}}</p><br>
                    <button class="orderok" @click="orderok()">确认</button>
                </div>
            </el-col>
        </el-row>
    </div>
</template>

<script>
export default {
    name:'order',
    data(){
        return{
            orders:{
                orderid:'',
                addressid: '',
                paymoney:this.paymoney,
            },
            buycar:[
                {
                    bcgoodname:'商品名',
                    bcgoodimg:'manhua1.jpg',
                    bcgoodtype:'类型',
                    bcgoodprice:'100',
                    bcgoodnum:'1',
                    bcallprice:'100',
                    bcfreight:'1',
                    bcstorename:'商店名'
                }
            ],
            address: [{
                id: 1,
                value: '地址1111111111111111111111111111111111111111111'
                }, {
                id: 2,
                value: '地址2'
                }
            ],
            // curuser:'',
            curuser:JSON.parse(sessionStorage.getItem("user")).username,
            thispay:2,
            eleactive:'eleactive',
            onlinepay:false,     
            addresschoose:''   
        }
    },
    computed:{
        allmoney:function() {
            var allmoney = 0;
            for (let i = 0; i < this.buycar.length; i++) {
                allmoney += Number(this.buycar[i].bcallprice);
            }
            return allmoney;
        },
        freight:function() {
            var freight = 0;
            for (let i = 0; i < this.buycar.length; i++) {
                freight += Number(this.buycar[i].bcfreight);
            }
            return freight;
        },
        paymoney:function(){
            this.orders.ordertotalprice = this.allmoney+this.freight;
            return this.allmoney+this.freight;
        }
    },
    methods:{
        orderload(){
            axios.post(
                this.$webroot+'orders/load'
            ).then((response)=>{
                this.orders = response.data.order;
                this.orders.orderuserid = sessionStorage.getItem("user").userid
                this.buycar = response.data.buycar;
                this.address = response.data.address;
            }).catch((error)=>{
                console.log(error);
            })

        },
        thischange(val){
            console.log(this.orders.addressid);
            for (let i = 0; i < this.address.length; i++) {
                if (this.address[i].id == val) {
                    this.addresschoose = this.address[i].value;
                }
                
            }
            this.addressid
        },
        goodimg(val){
            return require(this.$webroot+''+val);
            // return require('../assets/'+val);
        },
        paychoose(val){
            this.thispay = val;
            if (val != 1) {
                this.onlinepay = false;
            }else{
                this.onlinepay = true;
            }
        },

        orderok(){
            axios.post(
                this.$webroot+'orders/update',
                JSON.stringify(this.orders)
            ).then((response)=>{
                if (response.data.err) {
                    alert("下订单失败，请重新确定订单信息");
                }
                if (this.onlinepay) {
                    this.$router.push({path:"/paymethod",params:{orderid:this.orders.orderid}});
                }else{
                    this.$router.push('/order');
                }
            }).catch((error)=>{
                console.log(error);
            })
            // if (this.onlinepay) {
            //     this.$router.push({path:"/paymethod",params:{orderid:this.orders.orderid}});
            // }else{
            //     this.$router.push('/order');
            // }
            
        }
    },
    mounted:function () {
        this.orderload();
    }

}
</script>

<style scoped>
    #order{
        width: 1200px;
        margin: 20px auto;
    }

    .ordertip{
        background-color:#FFD04B;
        color:white;
        padding: 10px;
    }

    .ordertip h2{
        margin: 0;
        padding: 0;
    }

    .onegood{
        /* border: 1px solid black; */
        margin: 0;
        padding: 0;
        display: flex;
    }

    .bcgname{
        display: inline-block;
        /* border: 1px solid black; */
        padding: 10px;
    }

    .nowuser{
        width: 30%;
        height: 50px;
        display: flex;
    }

    .nowuser span{
        line-height: 50px;
    }

    .users{
        display: inline-block;
        height: 50px;
        padding: 0 10px;
        text-align: center;
    }

    .address{
        width: 70%;
        height: 50px;
        padding-left: 10px;
    }

    .address span{
        line-height: 50px;
    }

    .pays{
        display: flex;
    }

    .pays span{
        display: inline-block;
        width: 100px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        cursor: pointer;
    }

    .eleactive{
        border: 2px solid #FFD04B;
    }

    .orderfooter{
        background-color: rgb(235, 235, 235);
    }

    .orderok{
        width: 100px;
        height: 50px;
        cursor: pointer;
        background-color: #FFD04B;
        outline: none;
        border: 1px solid #FFD04B;
    }
</style>