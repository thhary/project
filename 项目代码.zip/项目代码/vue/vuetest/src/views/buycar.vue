<template>
    <div id="buycar">
        <el-table
            ref="bctable"
            :data="bcvalue"
            tooltip-effect="dark"
            style="width: 100%"
            @selection-change="handleSelectionChange">
            <el-table-column
            type="selection"
            width="50">
            </el-table-column>
            <el-table-column
            prop="bcstorename"
            label="商店"
            width="100">
            </el-table-column>
            <el-table-column
            label="商品"
            width="500">
            <template slot-scope="scope">
                <div class="onegood">
                    <!-- <img :src="this.$webroot+''+scope.row.bcgoodimg" alt="" width="80px" height="80px"> -->
                    <img :src="goodimg(scope.row.good.goodimg)" alt="" width="100px" height="100px">
                    <span class="bcgname">{{ scope.row.good.goodname }}</span>
                </div>
            </template>
            </el-table-column>
            <el-table-column
            prop="good.goodpirce"
            label="单价"
            width="120">
            </el-table-column>
            <el-table-column
            label="数量"
            width="120">
            <template slot-scope="scope">
                <div class="goodnum">
                    <button @click="reducenum(scope.row.bcid)" class="setnum">-</button>
                    <span>{{scope.row.bcgoodnum}}</span>
                    <button @click="addnum(scope.row.bcid)" class="setnum">+</button>
                </div>
            </template>
            </el-table-column>
            <el-table-column
            prop="bcallprice"
            label="小计"
            width="120">
            </el-table-column>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                </template>
            </el-table-column>
            
        </el-table>
        <div class="bcfooter">
            <button @click="bcok()" class="okbtn" @mouseenter="isok=true" @mouseleave="isok=false" :class="isok?btnactive:''">结算</button>
            <span class="allgood">总价：<span>{{allmoney}}</span></span>
            <span class="allgood">已选商品：<span>{{allnum}}</span></span>
        </div>
    </div>
</template>

<script>
import qs from 'qs';

export default {
    name:'buycar',
    data(){
        return{
            bcvalue:[
                {
                    bcid:1,
                    good:{
                        goodid:1,
                        goodname:'商品名',
                        goodimg:'manhua1.jpg',
                        goodpirce:'100',
                    },
                    bcgoodnum:'1',
                    bcallprice:'',
                    bcstoreid:1,
                    bcstorename:'商店名',
                },
                {
                    bcid:2,
                    good:{
                        goodid:2,
                        goodname:'商品名',
                        goodimg:'manhua2.jpg',
                        goodpirce:'100',
                    },
                    bcgoodnum:'2',
                    bcallprice:'',
                    bcstoreid:1,
                    bcstorename:'商店名',
                },
            ],
            multipleSelection:[],
            isok:false,
            btnactive:'okbtnactive',
            buycaritem:{
                goodchoose:[],
            }
        }
    },
    computed:{
        allmoney:function () {
            var allmoney = 0;
            if (this.multipleSelection.length != 0) {
                for(var i = 0; i < this.multipleSelection.length; i++){
                    allmoney = allmoney + parseFloat(this.multipleSelection[i].bcallprice);
                    
                }
            }
            return allmoney;
        },
        allnum:function () {
            return this.multipleSelection.length;
        },
        
    },
    methods:{
        bcloading(){
            axios.post(
                this.$webroot+'buycars/find'
            ).then((response)=>{
                console.log(response.data)
                // this.bcvalue = response.data
            }).catch((error)=>{
                console.log(error);
            })
            for (let i = 0; i < this.bcvalue.length; i++) {
                this.bcvalue[i].bcallprice = Number(this.bcvalue[i].good.goodpirce)*Number(this.bcvalue[i].bcgoodnum);
                
            }
        },
        handleSelectionChange(val) {
            this.multipleSelection = [];
            this.buycaritem.goodchoose = [];
            for(var i = 0; i < val.length; i++){
                this.multipleSelection.push(val[i]);
                this.buycaritem.goodchoose.push(val[i].bcid);
            }
            console.log(JSON.stringify(this.buycaritem));
        },
        handleDelete(index, row) {
            console.log(index, row);
            axios.post(
                this.$webroot+'',
                "buycarid="+row.bcid
            ).then((response)=>{
                this.bcloading();
            }).catch((error)=>{
                console.log(error)
            })
        },
        goodimg(val){
            // return require(this.$webroot+'img/'+val);
            return require('../assets/'+val);
        },
        bcok(){
            if(this.multipleSelection == '' || this.multipleSelection == null){
                alert("请选定商品");
                return;
            }
            axios.post(
                this.$webroot+'buycars/delete',
                qs.stringify(this.buycaritem.goodchoose)
            ).then((response)=>{
                if(response.data.err){
                    console.log(response.data.err);
                    return;
                }
                this.$router.push("/order");
            }).catch((error)=>{
                console.log(error);
            });
            this.$router.push("/order");
        },
        addnum(val){
            for (let i = 0; i < this.bcvalue.length; i++) {
                if(this.bcvalue[i].bcid == val){
                    this.bcvalue[i].bcgoodnum = Number(this.bcvalue[i].bcgoodnum)+1;
                    this.bcvalue[i].bcallprice = parseFloat(this.bcvalue[i].good.goodpirce)*parseFloat(this.bcvalue[i].bcgoodnum);
                }  
            }
        },

        reducenum(val){
            for (let i = 0; i < this.bcvalue.length; i++) {
                if(this.bcvalue[i].bcid == val){
                    if (this.bcvalue[i].bcgoodnum != 0) {
                        this.bcvalue[i].bcgoodnum = Number(this.bcvalue[i].bcgoodnum)-1;
                        this.bcvalue[i].bcallprice = parseFloat(this.bcvalue[i].good.goodpirce)*parseFloat(this.bcvalue[i].bcgoodnum);
                    }  
                }
            }
        },
    },

    mounted:function () {
        this.bcloading();
    }

}
</script>

<style scoped>
    #buycar{
        width: 1200px;
        margin: 20px auto;
        /* border: 1px solid black; */
    }

    .bcfooter{
        width: 100%;
        height: 50px;
        background-color: rgb(221, 221, 221);
        display: flex;
        flex-direction: row-reverse;
    }

    .okbtn{
        width: 100px;
        height: 50px;
        outline: none;
        color: white;
        background-color: #FFD04B;
        border: 1px solid #FFD04B;
        font-size: 20px;
        cursor: pointer;
    }

    .okbtnactive{
        background-color: #ffbb00;
    }

    .onegood{
        /* border: 1px solid black; */
        margin: 0;
        padding: 0;
        display: flex;
    }

    .bcgname{
        display: inline-block;
        /* border: 1px solid black; */
        padding: 10px;
    }

    .allgood{
        display: inline-block;
        height: 50px;
        width: 130px;
        line-height: 50px;
    }

    .allgood span{
        font-size: 20px;
        color: red;
    }

    .goodnum button{
        outline: none;
    }

    .goodnum span{
        display: inline-block;
        text-align: center;
        width: 20px;
        height: 30px;
    }

    .setnum{
        height: 20px;
        border-radius: 50%;
        background-color: #FFD04B;
        color: white;
        border: 1px solid #FFD04B;
    }

    .addbc{
        margin-left: 30px;
        width: 150px;
        height: 50px;
        background-color: #FFD04B;
        color: white;
        border: 1px solid #FFD04B;
        padding: 0;
        font-size: 20px;
    }
</style>