import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import login from '../views/login.vue'
import sresult from '../views/searchresult.vue';
import gdetail from '../views/gooddetail.vue';
import buycar from '../views/buycar.vue';
import order from '../views/order.vue';
import orderlist from '../views/orderlist.vue';
import reg from '../views/reg.vue';

Vue.use(VueRouter)

const routes = [{
        path: '/',
        name: 'Home',
        component: Home
    },
    {
        path: '/login',
        name: 'login',
        component: login
    },
    {
        path: '/sresult',
        name: 'sresult',
        component: sresult
    },
    {
        path: '/gdetail',
        name: 'gdetail',
        component: gdetail
    },
    {
        path: '/buycar',
        name: 'buycar',
        component: buycar
    },
    {
        path: '/order',
        name: 'order',
        component: order
    },
    {
        path: '/orderlist',
        name: 'orderlist',
        component: orderlist
    },
    {
        path: '/reg',
        name: 'reg',
        component: reg
    },
    {
        path: '/about',
        name: 'About',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () =>
            import ( /* webpackChunkName: "about" */ '../views/About.vue')
    }
]

const router = new VueRouter({
    routes
})

router.beforeEach((to, from, next) => {
    console.log('经过路由拦截器');
    // 观察一下你想跳转的页面有没有needlogin标志
    var y = to.matched.some(function(res) {
        return res.meta.needlogin
    });
    // 有没有标志(一定要登录)
    if (!y) {
        // 没有就放过去
        next();
    } else if (sessionStorage.getItem("user") != null) { //有登陆标志，查看是否登录
        // 有登录就放过去
        next();
    } else {
        // 没有登录就跳转到登录页面
        next({ path: '/login' });
    }
});

export default router