<template>
  <div class="foot">
      <el-row class="pic">
          <el-col :span="6">
              <img src="../assets/foot_01.png"/>
                <span> 7天无理由退货</span>
          </el-col>
          <el-col :span="6">
              <img src="../assets/foot_02.png"/>
                <span> 质量保障</span>
          </el-col>
          <el-col :span="6">
              <img src="../assets/foot_03.png"/>
                <span> 快速配送</span>
          </el-col>
          <el-col :span="6">
              <img src="../assets/foot_04.png"/>
                <span> 优质优惠</span>
          </el-col>

      </el-row>
      <hr/>
      <el-row>
        <el-col :span="4">
            <h3>购物指南</h3>
            <p>购物流程</p>
            <p>会员介绍</p>
            <p>生活旅行</p>
            <p>大家电</p>
            <p>联系客服</p>
        </el-col>
        <el-col :span="4">
            <h3>配送方式</h3>
            <p>211限时达</p>
            <p>送货上门</p>
            <p>送货服务查询</p>
            <p>配送费收取标准</p>
            <p>海外配送</p>
        </el-col>
        <el-col :span="4">
            <h3>支付方式</h3>
            <p>货到付款</p>
            <p>在线支付</p>
            <p>分期付款</p>
            <p>公司转账</p>
        </el-col>
        <el-col :span="4">
            <h3>售后服务</h3>
            <p>售后政策</p>
            <p>价格保护</p>
            <p>退款说明</p>
            <p>返修/退换货</p>
            <p>取消订单</p>
        </el-col>
        <el-col :span="4">
            <h3>特色服务</h3>
            <p>延保服务</p>
            <p>DIY</p>
            <p>好货推荐</p>
        </el-col>
        <el-col :span="4">
            <h3>购物保障</h3>
            <p>7天无理由退货</p>
            <p>发票保障</p>
            <p>售后规则</p>
            <p>缺货赔付</p>
        </el-col>
    </el-row>
  </div>
</template>

<script>
export default {

}
</script>

<style>
    .pic img{
        vertical-align:middle;
    }
    .pic span{
        font-size:22px;
        font-weight:900;
    }

    .foot{
        margin-top:30px;
    }
</style>