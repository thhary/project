<template>
    <el-row type="flex" justify="space-between">
        <el-col class="types" >
            <!-- 商品分类导航栏（下拉菜单式） -->
            <div @mouseenter="typeshow1()" @mouseleave="typehidden()">
                <span class="goodtype" >
                    商品分类
                </span>
                <el-collapse-transition class="typeitem">
                    <ul v-show="showtype" class="typeitem">
                        <li v-for="t in typesitem"
                            :key="t.typeid"
                            @mouseenter="typeshow2(t)"
                            @mouseleave="isactive = !isactive"
                            :class="isactive&& thisid == t.typeid?liactive:''">
                            {{t.typename}}
                        </li>
                    </ul>
                </el-collapse-transition>
                <div class="type2" v-show="showtype2">
                    <div v-for="t in typesons" :key="t.typeid" class="tson">
                        <div class="tsonname">{{t.typename}}&gt;</div>
                        <div class="tgrandson" v-for="tgs in t.sontypes" :key="tgs.typeid" @click="typepush(tgs.typeid)">{{tgs.typename}}</div>
                    </div>
                </div>
            </div>
        </el-col>
        <el-col class="mainnav">
            <ul class="navul">
                <li v-for="(ni,index) in navitems"
                    :key="index" 
                    @mouseenter="thisnav = index"
                    @mouseleave="thisnav = -1">
                    <router-link :to="ni.navpath" :class="[navdefault,{navactive:thisnav == index}]" @click="removeother()">{{ni.itemname}}</router-link>
                </li>
                
            </ul>
        </el-col>
    </el-row>
</template>

<script>
import qs from 'qs';
import vuelist from './vuelist';

export default {
    components:{
        vuelist
    },
    inject:['reload'],
    data(){
        return{
            showtype:false,
            showtype2:false,
            typesitem:[
                {typeid:1, typename:"小鸡鸡",
                    sontypes:[{typeid:4,typename:"小小积极",
                        sontypes:[
                            {typeid:10,typename:"小小小鸡鸡"},
                            {typeid:11,typename:"小小小鸡鸡"},
                            {typeid:12,typename:"小小小鸡鸡"}
                        ]
                    },
                    {typeid:5,typename:"小小积极",
                        sontypes:[
                            {typeid:13,typename:"小小小鸡鸡"},
                            {typeid:14,typename:"小小小鸡鸡"},
                            {typeid:15,typename:"小小小鸡鸡"}
                        ]
                    },
                    {typeid:6,typename:"小小积极",
                        sontypes:[
                            {typeid:16,typename:"小小小鸡鸡"},
                            {typeid:17,typename:"小小小鸡鸡"},
                            {typeid:18,typename:"小小小鸡鸡"}
                        ]
                    }
                    ]
                },
                {typeid:2, typename:"迷你鸡鸡",
                    sontypes:[{typeid:7,typename:"迷你积极",
                        sontypes:[
                            {typeid:19,typename:"迷你鸡鸡"},
                            {typeid:20,typename:"迷你鸡鸡"},
                            {typeid:21,typename:"迷你鸡鸡"}
                        ]
                    },
                    {typeid:8,typename:"迷你积极",
                        sontypes:[
                            {typeid:22,typename:"迷你鸡鸡"},
                            {typeid:23,typename:"迷你鸡鸡"},
                            {typeid:24,typename:"迷你鸡鸡"}
                        ]
                    },
                    {typeid:9,typename:"迷你积极",
                        sontypes:[
                            {typeid:25,typename:"迷你鸡鸡"},
                            {typeid:26,typename:"迷你鸡鸡"},
                            {typeid:27,typename:"迷你鸡鸡"}
                        ]
                    }
                    ]
                }
            ],
            typesons:'',
            isactive:false,
            liactive:'typeliactive',
            thisid:'',
            navitems:[
                {itemname:'首页',navpath:'/'},
                {itemname:'服装',navpath:''},
                {itemname:'生活用品',navpath:''},
                {itemname:'电器',navpath:''},
                {itemname:'电子数码',navpath:''},
                {itemname:'热销',navpath:''}
            ],
            navdefault:'rlink',
            navactive:'navactive',
            thisnav:-1
        }
    },
    methods: {
        handleSelect(key, keyPath) {
            console.log(key, keyPath);
        },
        typeshow1(){
            this.showtype = true;
        },
        typeshow2(val){
            this.showtype2 = true;
            this.typesons = val.sontypes;
            this.isactive = true;
            this.thisid = val.typeid;
        },
        typepush(val){
            var thispath = this.$route.path;
            this.$store.commit("updatetype",val);
            if(thispath == "/sresult"){ 
                this.reload();
            }else{
                this.$router.push("/sresult");
            }
            
            
        },
        typehidden(){
            this.showtype = false;
            this.showtype2 = false;
        },
        navitemactive(val){
            this.navactive = val;
        },

        removeother(){
            this.$store.commit('removesearch')
        }
    },
    computed:{
        tgrandsons(){
            return this.typesons.sontypes
        }
    }
}
</script>

<style scoped>
    .types{
        position: relative;
        background-color: #FFD04B;
        width: 150px;
        /* border: 1px solid black; */
    }

    .goodtype{
        display: inline-block;
        width: 150px;
        height: 50px;
        line-height: 50px;
        font-size: 20px;
        text-align: center;
        color: white;
        cursor: pointer;
    }

    .typeitem{
        position: absolute;
        z-index: 10;
        background-color: #FFD04B;
    }

    .typeitem li{
        cursor: pointer;
    }

    .typeliactive{
        background-color: white;
        color: #FFD04B;
    }

    .types ul{
        list-style: none;
        padding: 0;
        margin: 0;
        width: 150px;
        text-align: center;
    }
    
    .types ul li{
        width: 100%;
        height: 40px;
        line-height: 40px;
    }

    .type2{
        height: 400px;
        min-width: 745px;
        position: absolute;
        left: 150px;
        top: 50px;
        background-color: white;
        z-index: 10;
    }

    .tson{
        margin: 10px 0;
    }

    .tsonname{
        padding: 10px;
        color: #FFD04B;
    }

    .tgrandson{
        display: inline-block;
        padding: 0 10px;
        cursor: pointer;
    }

    .navul{
        display: flex;
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .navul li{
        display: inline-block;
        width: 100px;
        height: 50px;
    }

    .rlink{
        display: inline-block;
        width: 100px;
        height: 50px;
        line-height: 50px;
        text-decoration: none;
        text-align: center;
        color: #FFD04B;
    }

    .navactive{
        background-color: #FFD04B;
        color: white;
    }   
</style>