<template>
    <div>
        <div v-for="l in list" :key="l.typeid" class="div1">
            <div>{{l.typename}}</div>
            <div v-if="l.sontypes" class="div2">
                <vuelist :list="l.sontypes"></vuelist>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name:"vuelist",
    props:[
        "list"
    ]

}
</script>

<style scoped>
    .div2{
        display: inline;
    }

</style>