<template>
    <div class="gsearch">
        <label for="searchgood">搜索</label>
        <div class="inputset">
            <i class="el-icon-search eliconset"></i>
            <input type="text" @keyup.enter="searchlist()" v-model="inputcontent" id="searchgood" placeholder="请输入你要搜索的商品">
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            inputcontent:"",
        }
    },
    inject:['reload'],
    methods:{
        searchlist(){
            var thispath = this.$route.path;
            this.$store.commit("updateinput",this.inputcontent);
            if (thispath == '/sresult') {
                // console.log("当前页面");
                this.reload();
            }else{
                this.$router.push("/sresult");
            }
            this.inputcontent = '';    
        }
    }
}
</script>

<style scoped>
.gsearch{
    background-color: #FFD04B;
    border-radius: 25px;
    padding: 5px 10px;
    display: flex;
    justify-content: space-between;
}

.gsearch input{
    width: 100%;
    box-sizing: border-box;
    height: 40px;
    line-height: 40px;
    font-size: 18px;
    border:  1px solid #FFD04B;
    border-radius: 20px;
    outline: none;
    padding-left: 35px;
}

.gsearch label{
    text-align: center;
    color: white;
    line-height: 40px;
    font-size: 18px;
    width: 10%;
}

.gsearch i{
    position: absolute;
    top: 12px;
    left: 10px;
}

.inputset{
    position: relative;
    width: 90%;
}


</style>