<template>
    <el-carousel :interval="5000" height="400px">
        <el-carousel-item v-for="item in items" :key="item.index">
                <img :src="pictureurl(item)" alt="" style="width:100%;height:100%">            
        </el-carousel-item>
  </el-carousel>
</template>

<script>
export default {
    data(){
        return{
            items:["manhua1.jpg","manhua2.jpg","manhua3.jpg","manhua4.jpg"]
        }
    },

    methods:{
        pictureurl:function(val){
            return require("../assets/"+val);
        }
    }
    
}
</script>

<style scoped>

</style>