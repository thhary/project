<template>
  <el-row type="flex" justify="space-between" class="header">
    <el-col :span="6">
      <img src="../assets/loveshop.png">
    </el-col>
    <el-col :span="6">
      <img src="../assets/rbglogo.png">
    </el-col>
  </el-row>
</template>

<script>
export default {

}
</script>

<style>
  .header{
      padding: 5px 50px;
  }

</style>