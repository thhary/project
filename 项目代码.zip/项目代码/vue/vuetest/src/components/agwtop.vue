<template>
    <div>
        <el-row style="background-color:#F3F3F3">
            <el-col :span="24">
                <el-menu class="el-menu-demo eltopset" mode="horizontal" @select="handleSelect" background-color="#F3F3F3">
                    <el-menu-item index="1" v-if="islogin"><el-avatar :size="50" :src="circleUrl"></el-avatar></el-menu-item>
                    <el-menu-item index="1" v-else @click="login()"><router-link to="/login" class="rlink">登录</router-link></el-menu-item>
                    <el-menu-item index="2" v-if="islogin" @click="userexit()">注销</el-menu-item>
                    <el-menu-item index="2" v-else><router-link to="/reg" class="rlink">注册</router-link></el-menu-item>
                    <el-menu-item index="3"><router-link to="/orderlist" class="rlink">我的订单</router-link></el-menu-item>
                    <el-submenu index="4">
                        <template slot="title">我的记录</template>
                        <el-menu-item index="4-1">商店收藏</el-menu-item>
                        <el-menu-item index="4-2">商品收藏</el-menu-item>
                        <el-menu-item index="4-3"><router-link to="/buycar" class="rlink">购物车</router-link></el-menu-item>
                    </el-submenu>
                    <el-submenu index="5">
                        <template slot="title">客户服务</template>
                        <el-menu-item index="5-1">联系客服</el-menu-item>
                        <el-menu-item index="5-2">帮助中心</el-menu-item>
                        <el-menu-item index="5-3">服务中心</el-menu-item>
                    </el-submenu>
                    <el-submenu index="6">
                        <template slot="title">关于我们</template>
                        <el-menu-item index="6-1">商城介绍</el-menu-item>
                        <el-menu-item index="6-2">官方微博</el-menu-item>
                    </el-submenu>
                </el-menu>
            </el-col>
        </el-row>
    </div>
</template>

<script>
export default {
    data() {
        return {
            islogin:"",
            circleUrl:'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',
            // circleUrl:this.$webroot+""+JSON.parse(sessionStorage.getItem("user")).img
        };
    },
    methods: {
        handleSelect(key, keyPath) {
            console.log(key, keyPath);
        },
        userlogin(){
            var user = sessionStorage.getItem("user");
            if(user){
                this.islogin = true;
                this.circleUrl = this.$webroot + '' +user.img;
            }else{
                this.islogin = false;
            }
        },
        userexit(){
            sessionStorage.removeItem("user");
            this.userlogin();
            // this.$router.push("/login");
        },
    },
    mounted(){
        this.userlogin();
    }

}
</script>

<style scoped>
.eltopset{
    float: right;
    padding: 0;
}

.rlink{
    width: 100%;
    height: 100%;
    display: inline-block;
    text-decoration: none;
    color: gray;
}


</style>