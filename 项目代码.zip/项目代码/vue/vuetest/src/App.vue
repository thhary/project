<template>
  <div id="app">
    <el-container>
      <el-header v-if="$route.name!='login'&&$route.name!='reg'" height="200px">
        <!-- 顶部导航 -->
        <el-row>
          <el-col :span="24">
            <agwtop></agwtop>
          </el-col>
        </el-row>
        <!-- 搜索栏 -->
        <el-row type="flex" justify="center" style="padding:20px 0;width:1200px;margin:auto">
          <el-col :span="12">
            <gsearch></gsearch>
          </el-col>
        </el-row>
        <!-- 商品导航 -->
        <el-row type="flex" justify="center" style="width:1200px;margin:auto">
          <el-col :span="24">
            <agwnav></agwnav>
          </el-col>
        </el-row>
      </el-header>

      <el-main>
        <!-- 视图 -->
        <router-view v-if="isrouteralive"></router-view>
      </el-main>

      <!-- 底部内容 -->
      <el-footer>
        <el-row>
          <el-col>

          </el-col>
        </el-row>
      </el-footer>
  </el-container>
  </div>
</template>

<script>
import agwtop from './components/agwtop';
import gsearch from './components/goodsearch';
import agwnav from './components/agwgoodnav';


export default {
  name: 'app',
  components: {
    agwtop,
    gsearch,
    agwnav
  },
  beforeRouteEnter (to, from, next) {
    console.log("beforerouter");
    console.log(to.name);
  },
  data(){
    return{
      isrouteralive:true,
    }
  },
  provide(){
    return{
      reload:this.reload
    }
  },
  methods:{
    reload(){
      this.isrouteralive = false;
      this.$nextTick(function () {
        this.isrouteralive = true;
      })
    },
    sHead:function(val){
      this.showHead=val;
    }
  },
}
</script>

<style scoped>

#app{
  width: 100%;
  min-width: 1200px;
  margin: 0 auto;
  padding: 0;
}

.el-header,.el-main,.el-footer{
  padding: 0;
  margin:0;
}

</style>
