import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    inputcontent:'',
    typeid:'',
  },
  mutations: {
    updateinput(state,ipc){
      state.inputcontent = ipc
    },
    removesearch(state){
      state.inputcontent = ''
      state.typeid = ''
    },
    updatetype(state,tid){
      state.typeid = tid
    },
  },
  actions: {
  },
  modules: {
  }
})
