// pages/list/list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[],
    money:0,
    button_color:"default",
    icon:0,
    address:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // const eventChannel = this.getOpenerEventChannel()
    /*eventChannel.on('list', function(list){
      console.dir(list.list)
      that.setData({
        list:list.list
      })
    }),
    eventChannel.on('money',function(money){
      console.dir(money.money)
      that.setData({
        money:money.money
      })
    })*/
    this.setData({
      list:JSON.parse(options.list),
      money:JSON.parse(options.money)
    })
    
    
  },

  onChange: function(e){
   this.setData({
    address:e.detail.value
   })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  button: function(){
    var button_color= this.data.button_color
    if(button_color=="default"){
      this.setData({
        button_color:"primary"
      })
    }
      else{
        this.setData({
          button_color:"default"
        })
    }
  },

  gotobuy: function(){
    var that =this
    this.setData({
      icon:1
    })
    setTimeout(function() {
      that.setData({
        icon:0
      })
      wx.reLaunch({
        url: '../home/home',
      })
   }, 2000);
  }
})