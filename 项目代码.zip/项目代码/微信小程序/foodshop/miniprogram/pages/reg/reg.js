// miniprogram/pages/reg/reg.js
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:'',
    pwd:'',
    pwd_again:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  onChange: function(e){
    var that = this;  
    if(e.target.id=="name"){  
      that.setData({
        name:e.detail.value
      })
    }else if(e.target.id=='pwd'){
      that.setData({
        pwd:e.detail.value
      })
    }else if(e.target.id=='pwd_again'){
      that.setData({
        pwd_again:e.detail.value
      })
    }
    
  },
  reg: function(){
    var that = this;
    if(that.data.pwd!=''||that.data.pwd!=null)
    if(that.data.pwd==that.data.pwd_again){
      db.collection('account').add({
        data: {
          name:that.data.name,
          pwd:that.data.pwd
        },
        success:function(res){
          wx.showToast({
            title: '注册成功！',
          })
          setTimeout(function(){
            wx.navigateBack({
              delta: 1,
            })
          },1000)
        }
      })
    }
    else{
      wx.showToast({
        title: '两次密码不相同',
      })
    }
  }
})