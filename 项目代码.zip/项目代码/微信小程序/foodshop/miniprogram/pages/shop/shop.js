//index.js
//获取应用实例
const app = getApp()

const db = wx.cloud.database()
var menuitem = [];
// 右侧每一类的 bar 的高度（固定）
const RIGHT_BAR_HEIGHT = 27;
// 右侧每个子类的高度（固定）
const RIGHT_ITEM_HEIGHT = 108;

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    currentLeftSelect: null,
    menuitem: [],
    intoview: null,
    shopping_num: 0,
    is_list: 0,
    list: [],
    money: 0,
    oldmoney: 0
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    var that =this;
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }

    db.collection('commodity').get({
      success: function (res) {
        menuitem = res.data;
        console.log(menuitem);
        that.setData({
          currentLeftSelect: menuitem[0].id,
          menuitem: menuitem
        })
      }
    })

  },
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  menubar: function (e) {
    // console.dir(e);
    let that = this;
    that.setData({
      currentLeftSelect: e.currentTarget.dataset.id,
      intoview: e.currentTarget.dataset.id
    })
  },

  right_height: function (e) {
    let height = [menuitem.length + 1]
    height[0] = 0
    let v = 0
    for (let item = 0; item < menuitem.length; item++) {
      v = menuitem[item].category.length * RIGHT_ITEM_HEIGHT + RIGHT_BAR_HEIGHT + v
      height[item + 1] = v
    }
    // console.log(height)
    return height
  },

  right_scroll: function (e) {
    // console.dir(e.detail.scrollTop)
    let a = e.detail.scrollTop + 1
    let height = this.right_height()
    for (let h = 0; h < menuitem.length; h++) {
      if (a < height[h + 1] && a >= height[h]) {
        this.setData({
          currentLeftSelect: menuitem[h].id
        })
        break;
      }
    }
  },

  right_sub: function (e) {
    // console.dir(e)
    let a = e.target.dataset.num
    let shopping_num = this.data.shopping_num
    if (a <= 0) {
      return
    }
    let parentindex = e.target.dataset.parentindex
    let index = e.target.dataset.index
    let b = "menuitem[" + parentindex + "].category[" + index + "].num"
    let c = this.data.menuitem[parentindex].category[index]
    let list = this.data.list
    var money = 0, oldmoney = 0
    for (let d = 0; d < list.length; d++) {
      if (c.id == list[d].id) {
        list[d].num--
        if (list[d].num == 0) {
          console.log(list)
          list.splice(d, 1)
          console.log(list)
        }
        // console.log(list)
        break
      }
    }
    for (let e = 0; e < list.length; e++) {
      money = money + list[e].price * list[e].num
      oldmoney = oldmoney + list[e].oldprice * list[e].num
    }
    money = money.toFixed(1)
    oldmoney = oldmoney.toFixed(1)

    this.setData({
      [b]: --a,
      shopping_num: shopping_num - 1,
      list: list,
      money: money,
      oldmoney: oldmoney
    })
  },

  right_plus: function (e) {
    // console.dir(e)
    let a = e.target.dataset.num
    let shopping_num = this.data.shopping_num
    if (a >= 99) {
      return
    }
    let parentindex = e.target.dataset.parentindex
    let index = e.target.dataset.index
    let b = "menuitem[" + parentindex + "].category[" + index + "].num"
    let c = this.data.menuitem[parentindex].category[index]
    var list = this.data.list
    var money = 0, oldmoney = 0
    list = list.concat(c)
    for (let d = 0; d < list.length - 1; d++) {
      if (c.id == list[d].id) {
        list[d].num++
        list.splice(list.length - 1, 1)
        break
      }
    }
    this.setData({
      [b]: ++a,
      shopping_num: shopping_num + 1,
      list: list,
    })

    for (let e = 0; e < list.length; e++) {
      money = money + list[e].price * list[e].num
      oldmoney = oldmoney + list[e].oldprice * list[e].num
    }
    money = money.toFixed(1)
    oldmoney = oldmoney.toFixed(1)
    this.setData({
      money: money,
      oldmoney: oldmoney
    })
  },

  //关闭购物车列表
  list_close: function (e) {
    let that = this
    let is_list = this.data.is_list
    let shopping_num = this.data.shopping_num
    if (is_list == 0 && shopping_num > 0) {
      that.setData({
        is_list: 1
      })
    }
    else {
      that.setData({
        is_list: 0
      })
    }
  },

  list_sub: function (e) {
    let num = e.target.dataset.num - 1
    let index = e.target.dataset.index
    let id = e.target.dataset.id
    let list = this.data.list
    let menuitem = this.data.menuitem
    let shopping_num = this.data.shopping_num
    var money = 0, oldmoney = 0
    for (let a = 0; a < menuitem.length; a++) {
      for (let b in menuitem[a].category) {
        if (id == menuitem[a].category[b].id) {
          menuitem[a].category[b].num--
          for (let e = 0; e < list.length; e++) {
            money = money + list[e].price * list[e].num
            oldmoney = oldmoney + list[e].oldprice * list[e].num
          }
          money = money.toFixed(1)
          oldmoney = oldmoney.toFixed(1)
          this.setData({
            menuitem: menuitem,
            shopping_num: --shopping_num,
            money: money,
            oldmoney: oldmoney
          });
          break
        }
      }
    }
    if (num <= 0) {
      list.splice(index, 1)
      if (list.length == 0) {
        this.setData({
          is_list: 0,
          shopping_num: 0
        })
      }
    }
    else {
      list[index].num = num
    }
    this.setData({
      list: list
    })
  },

  list_plus: function (e) {
    let num = e.target.dataset.num
    let index = e.target.dataset.index
    let id = e.target.dataset.id
    let list = this.data.list
    let menuitem = this.data.menuitem
    let shopping_num = this.data.shopping_num
    var money = 0, oldmoney = 0
    if (shopping_num <= 99) {
      for (let a = 0; a < menuitem.length; a++) {
        for (let b in menuitem[a].category) {
          if (id == menuitem[a].category[b].id) {
            menuitem[a].category[b].num++
            list[index].num = ++num
            for (let e = 0; e < list.length; e++) {
              money = money + list[e].price * list[e].num
              oldmoney = oldmoney + list[e].oldprice * list[e].num
            }
            money = money.toFixed(1)
            oldmoney = oldmoney.toFixed(1)
            this.setData({
              menuitem: menuitem,
              shopping_num: ++shopping_num,
              list: list,
              money: money,
              oldmoney: oldmoney
            })
            break
          }
        }
      }
    }
  },

  clear: function (e) {
    var menuitem = this.data.menuitem
    for (let a = 0; a < menuitem.length; a++) {
      for (let b in menuitem[a].category) {
        menuitem[a].category[b].num = 0
      }
    }
    this.setData({
      list: [],
      menuitem: menuitem,
      shopping_num: 0,
      is_list: 0,
      money: 0,
      oldmoney: 0
    })
  },

  goto: function (e) {
    var list = this.data.list
    if (list.length == 0) {
      return
    }
    var list = JSON.stringify(this.data.list)
    var money = JSON.stringify(this.data.money)
    wx.navigateTo({
      url: '../list/list?list='+list+'&money='+money,
      // success: function (res) {
      //   res.eventChannel.emit('list', { list: list })
      //   res.eventChannel.emit('money', { money: money })
      // }
    })
  }
})