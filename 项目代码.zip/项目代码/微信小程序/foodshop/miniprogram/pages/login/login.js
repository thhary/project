// miniprogram/pages/login/login.js
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:'',
    pwd:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  onChange: function(e){
    var that = this;  
    if(e.target.id=="name"){  
      that.setData({
        name:e.detail.value
      })
    }else if(e.target.id=='pwd'){
      that.setData({
        pwd:e.detail.value
      })
    }
  },

  login: function(){
    var that = this;
    
    db.collection('account').where({
      name:that.data.name,
      pwd:that.data.pwd
    }).get({
      success: function(res){
        console.log(res);
        wx.switchTab({
          url: '/pages/home/home',
        })
      }
    })
  },

  reg: function(){
    wx.navigateTo({
      url: '/pages/reg/reg',
    })
  }
})