// components/shops/shops.js
const db = wx.cloud.database()
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    shops:null
  },

  lifetimes: {
    attached: function() {
      // 在组件实例进入页面节点树时执行
      var that = this;
    db.collection('shops').where({
      type:2
    }).get({
      success: function(res){
        console.log(res.data);
        that.setData({
          shops:res.data
        })
      }
    })
    },
    detached: function() {
      // 在组件实例被从页面节点树移除时执行
    },
  },

  /**
   * 组件的方法列表
   */
  methods: {
    shop: function() {
      wx.navigateTo({
        url: '/pages/shop/shop',
      })
    }
  }
})
